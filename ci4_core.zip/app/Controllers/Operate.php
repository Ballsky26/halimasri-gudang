<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Barang_model;
use App\Models\Supplier_model;
use App\Models\Distributor_model;
use App\Models\Transaction_model;

class Operate extends Controller
{
    public function index()
    {
        $data['title'] = 'Tambah Transaksi | Halima Sri';
        $model = new Barang_model();
        $supplier = new Supplier_model();
        $distributor = new Distributor_model();     
        $data['all'] = $model->getProduct();
        $data['cBarang'] = $model->countBarang();
        $data['cSupplier'] = $supplier->countSupplier();
        $data['cDistributor'] = $distributor->countDistributor();
        $data['supplier'] = $supplier->getSupplier();
        $data['distributor'] = $distributor->getDistributor();
        
        echo view('header_view',$data);
        echo view('nav_view');
        echo view('engineer/operate_view',$data);
        echo view('footer_view');
    }

    public function index2()
    {
        $data['title'] = 'Tambah Transaksi | Halima Sri';
        $model = new Barang_model();
        $supplier = new Supplier_model();
        $distributor = new Distributor_model();     
        $data['all'] = $model->getProduct();
        $data['cBarang'] = $model->countBarang();
        $data['cSupplier'] = $supplier->countSupplier();
        $data['cDistributor'] = $distributor->countDistributor();
        $data['supplier'] = $supplier->getSupplier();
        $data['distributor'] = $distributor->getDistributor();
        
        echo view('header_view',$data);
        echo view('nav_view_v2');
        echo view('engineer/operate_view_v2',$data);
        echo view('footer_view');
    }

    public function laporan()
    {
        $data['title'] = 'Laporan | Halima Sri';
        $model = new Transaction_model();
        $data['active'] = "laporan";

        $data['all'] = $model->loadData();
        $data['masuk'] = $model->getDataMasuk();
        $data['keluar'] = $model->getDataKeluar();
        
        echo view('header_view',$data);
        echo view('nav_view',$data);
        echo view('engineer/laporan',$data);
        echo view('footer_view');
    }

    public function all_trans()
    {
        $data['title'] = 'Semua Transaksi | Halima Sri';
        $model = new Transaction_model();
        $data['active'] = "transaksi";

        $data['all'] = $model->getDataLinked();
        
        echo view('header_view',$data);
        echo view('nav_view',$data);
        echo view('engineer/all_trans',$data);
        echo view('footer_view');
    }

    public function all_trans_v2()
    {
        $data['title'] = 'Semua Transaksi | Halima Sri';
        $model = new Transaction_model();
        $data['active'] = "transaksi";

        $data['all'] = $model->getDataLinked();
        
        echo view('header_view',$data);
        echo view('nav_view_v2',$data);
        echo view('engineer/all_trans_v2',$data);
        echo view('footer_view');
    }

    public function all_trans_search()
    {
        $data['title'] = 'Pencarian Transaksi | Halima Sri';
        $model = new Transaction_model();
        $data['active'] = "transaksi";
        $tahun = $this->request->getPost('tahun');
        $bulan = $this->request->getPost('bulan');
        
        $data['all'] = $model->getDataLinkedFilter($tahun,$bulan);
        
        echo view('header_view',$data);
        echo view('nav_view',$data);
        echo view('engineer/all_trans',$data);
        echo view('footer_view');
    }

    public function all_trans_search_v2()
    {
        $data['title'] = 'Pencarian Transaksi | Halima Sri';
        $model = new Transaction_model();
        $data['active'] = "transaksi";
        $tahun = $this->request->getPost('tahun');
        $bulan = $this->request->getPost('bulan');
        
        $data['all'] = $model->getDataLinkedFilter($tahun,$bulan);
        
        echo view('header_view',$data);
        echo view('nav_view_v2',$data);
        echo view('engineer/all_trans_v2',$data);
        echo view('footer_view');
    }

    public function transaksi()
    {
        $data['title'] = 'Transaksi | Halima Sri';
        $model = new Barang_model();
        $supplier = new Supplier_model();
        $distributor = new Distributor_model();
        $transaksi = new Transaction_model();
        $data['active'] = "transaksi";   
        $data['all'] = $model->getProduct();
        $data['cBarang'] = $model->countBarang();
        $data['cSupplier'] = $supplier->countSupplier();
        $data['cDistributor'] = $distributor->countDistributor();
        $data['supplier'] = $supplier->getSupplier();
        $data['distributor'] = $distributor->getDistributor();
        $data['data'] = $transaksi->loadData();
        $data['dataAll'] = $transaksi->getTransaction();
        $data['dataAllLinked'] = $transaksi->getDataLinked();
        
        
        echo view('header_view',$data);
        echo view('nav_view');
        echo view('engineer/transaksi_view',$data);
        echo view('footer_view');
    }

    public function transaksi_viewer()
    {
        $data['title'] = 'Transaksi | Halima Sri';
        $model = new Barang_model();
        $supplier = new Supplier_model();
        $distributor = new Distributor_model();
        $transaksi = new Transaction_model();
        $data['active'] = "transaksi";   
        $data['all'] = $model->getProduct();
        $data['cBarang'] = $model->countBarang();
        $data['cSupplier'] = $supplier->countSupplier();
        $data['cDistributor'] = $distributor->countDistributor();
        $data['supplier'] = $supplier->getSupplier();
        $data['distributor'] = $distributor->getDistributor();
        $data['data'] = $transaksi->loadData();
        $data['dataAll'] = $transaksi->getTransaction();
        $data['dataAllLinked'] = $transaksi->getDataLinked();
        
        
        echo view('header_view',$data);
        echo view('nav_view_v2');
        echo view('engineer/transaksi_view_v2',$data);
        echo view('footer_view');
    }
    
    public function save_transaction(){
        $model = new Transaction_model();
        $data['hold'] = $this->request->getPost('holderAll');
        $data['label'] = $this->request->getPost('labelJenis');
        $data['idDis'] = $this->request->getPost('jenisDis');
        $data['idSup'] = $this->request->getPost('jenisSup');
        $data['sup'] = $this->request->getPost('typeNya');
        $new = json_decode($data['hold'], true);

        $id;
        if ($data['idSup'] != '') {
            $id = $data['idSup'];
        } else {
            $id = $data['idDis'];
        }
  
        //  siapkan data
        for ($x = 0; $x <= count($new); $x++) {
            // echo $new[$x]['id_barang'];

            // check
            if ($data['idSup'] != '') {
                $total_temp =  $new[$x]['jumlah_barang'] * 1;
            } else {
                $total_temp =  $new[$x]['jumlah_barang'] * -1;
            }

            $save[$x] = array(
                'id_barang' => $new[$x]['id_barang'],
                'id_mitra' => $id,
                'id_admin' => '1',
                'value' => $total_temp,
                'tipe' => $data['sup'],
            );

        }
        // insert data
        for ($x = 0; $x <= count($save); $x++) {
            // echo $new[$x]['id_barang'];
            $trace = $model->saveTransaction($save[$x]);
        }

        session()->setFlashdata('success', 'Barang Berhasil ditambahkan');
        return redirect()->to('/operate/transaksi');
    }

    public function save_transaction_v2(){
        $model = new Transaction_model();
        $data['hold'] = $this->request->getPost('holderAll');
        $data['label'] = $this->request->getPost('labelJenis');
        $data['idDis'] = $this->request->getPost('jenisDis');
        $data['idSup'] = $this->request->getPost('jenisSup');
        $data['sup'] = $this->request->getPost('typeNya');
        $new = json_decode($data['hold'], true);

        $id;
        if ($data['idSup'] != '') {
            $id = $data['idSup'];
        } else {
            $id = $data['idDis'];
        }
  
        //  siapkan data
        for ($x = 0; $x <= count($new); $x++) {
            // echo $new[$x]['id_barang'];

            // check
            if ($data['idSup'] != '') {
                $total_temp =  $new[$x]['jumlah_barang'] * 1;
            } else {
                $total_temp =  $new[$x]['jumlah_barang'] * -1;
            }

            $save[$x] = array(
                'id_barang' => $new[$x]['id_barang'],
                'id_mitra' => $id,
                'id_admin' => '1',
                'value' => $total_temp,
                'tipe' => $data['sup'],
            );

        }
        // insert data
        for ($x = 0; $x <= count($save); $x++) {
            // echo $new[$x]['id_barang'];
            $trace = $model->saveTransaction($save[$x]);
        }

        session()->setFlashdata('success', 'Barang Berhasil ditambahkan');
        return redirect()->to('/operate/transaksi_viewer');
    }
}
